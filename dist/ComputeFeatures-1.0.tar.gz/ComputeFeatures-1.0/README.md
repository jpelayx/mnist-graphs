## GNNs with SLIC Superpixel

## Datasets

### MNIST
Performance stats [here](https://docs.google.com/spreadsheets/d/1kSUZvOLq8QyniwMOj9HKeVuTXG9VD3Zsca1TydInLIQ/edit?usp=sharing)

### FASHION MNIST 
Performance stats [here](https://docs.google.com/spreadsheets/d/1dcAZQZT7tLmd8Q9JRJpvVx5WmwnNy4HKYAXROTlD7xk/edit?usp=sharing)

### CIFAR10
Performance stats [here](https://docs.google.com/spreadsheets/d/1xTd3UqqrIilJ2Qq268gOugvfmFQOBZ1I-g5w1-iuzAs/edit?usp=sharing)

### CIFAR100
Performance stats [here](https://docs.google.com/spreadsheets/d/1GIzFui3g4egHVmdRHHYPQD3qTCznBSyJSTs944rbrec/edit?usp=sharing)

### STL10
Performance stats [here](https://docs.google.com/spreadsheets/d/1fp4-SYxC15Gm54djVXvALHmCYf0u4BEIVmRHOmcZxYU/edit?usp=sharing)