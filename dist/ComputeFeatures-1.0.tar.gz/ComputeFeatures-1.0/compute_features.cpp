#include <Python.h>
#include <numpy/arrayobject.h>

static PyObject* compute_features_color(PyObject *self, PyObject *args)
{
    PyArrayObject *img;
    if(!PyArg_ParseTuple(args, "", &img))
        return NULL;
    
    PyArrayObject *x;
    int x_dims[3];
    x_dims[0] = 10;
    x_dims[1] = 10;
    x_dims[2] = 10;
    x = (PyArrayObject *) PyArray_FromDims(3, x_dims, PyArray_DOUBLE);
    if (x == NULL)
        return NULL;
    
    return PyArray_Return(x);    
}

static PyObject* compute_features_gray(PyObject *self, PyObject *args)
{
    PyArrayObject *img;
    if(!PyArg_ParseTuple(args, "s", &img))
        return NULL;
    
    PyArrayObject *x;
    int x_dims[3];
    x_dims[0] = 10;
    x_dims[1] = 10;
    x_dims[2] = 10;
    x = (PyArrayObject *) PyArray_FromDims(3, x_dims, PyArray_DOUBLE);
    if (x == NULL)
        return NULL;
    
    return PyArray_Return(x);    
}

static PyMethodDef compute_features_methods[] = {
    {"color_features", compute_features_color, METH_VARARGS, 
     "Computes features for RGB color datasets."},
    {"grayscale_features", compute_features_gray, METH_VARARGS, 
     "Computes features for grayscale datasets."}, 
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef compute_features_module = {
    PyModuleDef_HEAD_INIT, 
    "compute_features", 
    NULL, 
    -1,
    compute_features_methods
};

PyMODINIT_FUNC PyInit_compute_features(void)
{
    return PyModule_Create(&compute_features_module);
}